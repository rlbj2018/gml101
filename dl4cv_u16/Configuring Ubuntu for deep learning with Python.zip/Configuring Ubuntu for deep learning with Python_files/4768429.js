<html>
    <!-- Note: It is strongly recommended that you do NOT make large changes to this file. Changing DOM structure or classes may prevent
         the page from functioning correctly. Especially important pieces have been marked as such with comments
         and should not be changed for any reason. -->
<head>
    <meta charset="utf-8" />
    <title>Secure Web Browsing</title>
    <!-- This loads default Blue Coat styling -->
   	<style type="text/css">
   	<!--
       #logo a {
    background-image: url("//dca-app-703/bluecoat/exceptions/exception_logo.jpg");
    background-repeat: no-repeat;
    background-position: center center;
}
   	-->
   </style>
    <!-- This will load the default Blue Coat error page styling, as configured in the Blue Coat portal -->
    <link rel="stylesheet" type="text/css" href="//dca-app-703/bluecoat/exceptions/style.css" />
    <!-- This will load the Blue Coat favicon -->
    <link rel="shortcut icon" href="//dca-app-703/bluecoat/exceptions/favicon.ico" />
</head>
<body class="bodydrop">
<div id="outer">
    <div id="container" class="int curved">
        <div id="branding">
            <div class="curved" id="logo">
                <a rel="external" title="Applied Materials  Inc." href="http://www.appliedmaterials.com/">Applied Materials</a>
            </div>
        </div>
          <div id="content">
            <div id="bodyCopy">
                <div id="exceptionDetails" class="int">
                    <p id="httpCode">
                    </p>
                    <p>Your request was denied because of its content categorization: "Web Ads/Analytics"</p><p>Please contact Network Support to dispute the policy, or visit Blue Coat <a href="http://sitereview.bluecoat.com/index.jsp?referrer=bccloud&amp;url=https://tag.getdrip.com/4768429.js">Web Page Review</a> if you believe this URL is incorrectly categorized.</p><p>If you need further assistance, please contact the GIS Service Desk at <A
href='http://help'>http://help</a></b> or *5 from any AMAT phone.</p>
                    <div id="footer">
            <div id="copyright">&#169; 2017 DP1-SV2_ProxySG</div>
        </div>
    </div>
</div>
</div>
</div>
</body>
</html>